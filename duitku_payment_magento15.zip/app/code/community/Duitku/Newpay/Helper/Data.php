<?php

class Duitku_Newpay_Helper_Data extends Mage_Core_Helper_Abstract
{

  function _getTitle(){
    return Mage::getStoreConfig('payment/newpay/title');
  }

  function _getDescription(){
    return Mage::getStoreConfig('payment/newpay/payment_description');
  }

}

?>
