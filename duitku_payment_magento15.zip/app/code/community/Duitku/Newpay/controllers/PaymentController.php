<?php

class Duitku_Newpay_PaymentController extends Mage_Core_Controller_Front_Action
{
  protected function _getCheckout()
  {
    return Mage::getSingleton('checkout/session');
  }

  public function invoiceAction()
  {
    $orderId = $this->_getCheckout()->getLastRealOrderId();
    $orderData = Mage::getModel('sales/order')->loadByIncrementId($orderId);
    $sessionId = Mage::getSingleton('core/session');
    $merchantCode = Mage::getStoreConfig('payment/newpay/merchant_code');
    $apiKey = Mage::getStoreConfig('payment/newpay/api_key');
    $expiry = Mage::getStoreConfig('payment/newpay/expiry_period');

    $params = array();

    $billingAddressData = $orderData->getBillingAddress();
    $billingAddress = array();
    $billingAddress['address'] = $billingAddressData->getStreet(1);
    $billingAddress['city'] = $billingAddressData->getCity();
    $billingAddress['countryCode'] = "ID";
    $billingAddress['firstName'] = $billingAddressData->getFirstname();
    $billingAddress['lastName'] = $billingAddressData->getLastname();
    $billingAddress['phone'] = $billingAddressData->getTelephone();
    $billingAddress['postalCode'] = $billingAddressData->getPostcode();

    $shippingAddressData = $orderData->getShippingAddress();
    $shippingAddress = array();
    $shippingAddress['address'] = $shippingAddressData->getStreet(1);
    $shippingAddress['city'] = $shippingAddressData->getCity();
    $shippingAddress['countryCode'] = "ID";
    $shippingAddress['firstName'] = $shippingAddressData->getFirstname();
    $shippingAddress['lastName'] = $shippingAddressData->getLastname();
    $shippingAddress['phone'] = $shippingAddressData->getTelephone();
    $shippingAddress['postalCode'] = $shippingAddressData->getPostcode();

    $customerDetailParams = array();
    $customerDetailParams['email'] = $billingAddressData->getEmail();
    $customerDetailParams['firstName'] = $billingAddressData->getFirstname();
    $customerDetailParams['lastName'] = $billingAddressData->getLastname();
    $customerDetailParams['phoneNumber'] = $billingAddressData->getTelephone();
    $customerDetailParams["shippingAddress"] = $shippingAddress;
    $customerDetailParams["billingAddress"] = $billingAddress;

    $itemsData = $orderData->getAllItems();
    $shippingAmountData = $orderData->getShippingAmount();
    $shippingTaxAmountData = $orderData->getShippingTaxAmount();
    $taxAmountData = $orderData->getTaxAmount();

    $itemDetailParams = array();
    foreach ($itemsData as $value) {
      $item = array(
        'name' => $value->getName(),
        'price' => (int)$value->getPrice(),
        'quantity' => (int)($value->getQtyToInvoice())
      );
      $itemDetailParams[] = $item;
    }

    if($orderData->getDiscountAmount() != 0) {
      $couponItem = array(
        'name' => "Discount",
        'price' => (int)$orderData->getDiscountAmount(),
        'quantity' => 1
      );
      $itemDetailParams[] = $couponItem;
    }

    if($shippingAmountData > 0) {
      $shippingItem = array(
        'name' => 'Shipping Amount',
        'price' => (int)$shippingAmountData,
        'quantity' => 1
      );
      $itemDetailParams[] = $shippingItem;
    }

    if($shippingTaxAmountData > 0) {
      $shippingTaxItem = array(
        'name' => 'Shipping Tax Amount',
        'price' => (int)$shippingTaxAmountData,
        'quantity' => 1
      );
      $itemDetailParams[] = $shippingTaxItem;
    }

    if ($taxAmountData > 0) {
      $taxItem = array(
        'name' => 'Tax Amount',
        'price' => (int)$taxAmountData,
        'quantity' => 1
      );
      $itemDetailParams[] = $taxItem;
    }

    $currency = Mage::app()->getStore()->getCurrentCurencyCode();
    if($currency != 'IDR') {
      $convert = function ($notIdr) {
        return $notIdr * Mage::getStoreConfig('payment/newpay/convert_rate');
      };

      foreach ($itemDetailParams as $value) {
        $value['price'] = intval(round(call_user_func($convert, $value['price'])));
      }
    } else {
      foreach ($itemDetailParams as $value) {
        $value['price'] = (int)$value['price'];
      }
    }

    $paymentAmount = 0;
    foreach ($itemDetailParams as $item) {
      $paymentAmount += $item['price'];
    }

    $signature = md5($merchantCode.$orderId.$paymentAmount.$apiKey);

    $params['merchantCode'] = $merchantCode;
    $params['merchantOrderId'] = $orderId;
    $params['paymentAmount'] = $paymentAmount;
    $params['phoneNumber'] = $billingAddressData->getTelephone();
    $params['productDetails'] = "Order => #".$orderId;
    $params['signature'] = $signature;
    $params['email'] = $billingAddressData->getEmail();
    $params['expiryPeriod'] = (int)$expiry;
    $params['customerDetail'] = $customerDetailParams;
    $params['itemDetails'] = $itemDetailParams;
    $url = "https://dev-new.duitku.com/api/merchant/createInvoice";

    Mage::log(json_encode($params), null, 'duitkupay.log', true);

    if (extension_loaded('curl')) {
      try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json'
        ));
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));

        // Receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);

        curl_close ($ch);

        $respond = json_decode($server_output);

        if ($respond->statusCode == '00') {
          Mage::log('Reference number createInvoice = ' . $respond->reference, null, 'duitkupay.log', true);
          $this->_getCheckout()->setReference($respond->reference);

          foreach (Mage::getSingleton('checkout/session')->getQuote()->getItemsCollection() as $value) {
            Mage::getSingleton('checkout/cart')->removeItem($value->getId())->save();
          }

          Mage::app()->getFrontController()->getResponse()->setRedirect(Mage::getBaseUrl().'newpay/payment/popup');

        }else{
	  $this->_getCheckout()->setDuitkumessage($server_output);
          Mage::app()->getFrontController()->getResponse()->setRedirect(Mage::getBaseUrl().'newpay/payment/warning');
          error_log("Messages ".$server_output);
          Mage::log('error:' . print_r("Messages ".$server_output, true), null, 'duitkupay.log', true);
        }

      } catch(Exception $e) {
        error_log($e->getMessage());
        Mage::log('error:' . print_r($e->getMessage(), true), null, 'duitkupay.log', true);
      }
    } else {
      error_log("Duitku payment need curl extension, please enable curl extension in your web server");
      Mage::log('error:' . print_r("Duitku payment need curl extension, please enable curl extension in your web server", true), null, 'duitkupay.log', true);
    }
  }

  public function popupAction()
  {
    $template = 'newpay/popup.phtml';
    $this->loadLayout();
    $block = $this->getLayout()->createBlock(
      'Mage_Core_Block_Template',
      'newpay',
      array('template' => $template)
    );

    $this->getLayout()->getBlock('root')->setTemplate('page/1column.phtml');
    $this->getLayout()->getBlock('content')->append($block);
    $this->_initLayoutMessages('core/session');
    $this->renderLayout();
  }

  public function warningAction()
  {
    $template = 'newpay/warning.phtml';
    $this->loadLayout();
    $block = $this->getLayout()->createBlock(
       'Mage_Core_Block_Template',
       'newpay',
       array('template' => $template)
    ); 
    $this->getLayout()->getBlock('root')->setTemplate('page/1column.phtml');
    $this->getLayout()->getBlock('content')->append($block);
    $this->_initLayoutMessages('core/session');
    $this->renderLayout();
  }

}


?>
