<?php

class Duitku_Newpay_Model_Standard extends Mage_Payment_Model_Method_Abstract {

  protected $_code = 'newpay';

  protected $_isInitializeNeeded      = true;
  protected $_canUseInternal          = true;
  protected $_canUseForMultishipping  = false;

  protected $_formBlockType = 'newpay/form';
  protected $_infoBlockType = 'newpay/info';

  public function getOrderPlaceRedirectUrl() {
    return Mage::getUrl('newpay/payment/invoice', array('_secure' => true));
  }

}

?>
