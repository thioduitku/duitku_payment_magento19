<?php

/**
*
*/
class Duitku_Newpay_Model_System_Config_Environment
{

  public function toOptionArray()
  {
    return array(
      array('value' => 'development', 'label' => Mage::helper('newpay')->__('Development')),
      array('value' => 'sandbox', 'label' => Mage::helper('newpay')->__('Sandbox')),
      array('value' => 'production', 'label' => Mage::helper('newpay')->__('Production'))
    );
  }
}


?>
