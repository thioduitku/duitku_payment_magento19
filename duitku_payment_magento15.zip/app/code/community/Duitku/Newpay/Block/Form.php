<?php

class Duitku_Newpay_Block_Form extends Mage_Payment_Block_Form
{
  protected function _construct()
  {
    parent::_construct();
    $this->setFormMessage(Mage::helper('newpay/data')->_getDescription());
    $this->setTemplate('newpay/form.phtml');
  }
}

?>
