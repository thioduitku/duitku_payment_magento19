<?php

/**
*
*/
class Duitku_Newpay_Block_Info extends Mage_Payment_Block_Info
{

  protected function _construct()
  {
    parent::_construct();
    $this->setInfoMessage('<img src="'. $this->getSkinUrl('images/Duitku.png'). '"/>');
    $this->setPaymentMethodTitle( Mage::helper('newpay/data')->_getTitle() );
    $this->setTemplate('newpay/info.phtml');
  }
}


?>
